import java.util.ArrayList;
import java.util.List;

public class User {
	
	//write your code here
	
	public static List<User> prefill() {
		List<User> userList = new ArrayList<>();
		userList.add(new User("Harry","Male","harry@gmail.com","India"));
		userList.add(new User("Danny","Male","danny@gmail.com","England"));
		userList.add(new User("Joe","Male","joe@yahoo.com","Scotland"));
		userList.add(new User("Dean","Male","dean@rediff.com","India"));
		userList.add(new User("James","Male","james@google.com","Canada"));
		userList.add(new User("Matt","Male","matt@yahoo.com","USA"));
		userList.add(new User("Rob","Male","rob@hotmail.com","India"));
		userList.add(new User("Brandon","Male","brandon@gmail.com","Norway"));
		userList.add(new User("Emilia","Female","emilia@rediff.com","New Zealand"));
		userList.add(new User("Sophie","Female","sophie@hotmail.com","India"));
		userList.add(new User("Scarlett","Female","scarlett@gmail.com","Sri Lanka"));
		return userList;
	}	
	
	public static Map<String,String> rankOfUsers(List<User> userList,List<Question> questionList) {
		
		//write your code here
		
	}
}
